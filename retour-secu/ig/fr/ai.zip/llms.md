# ans.fhir.fr.pdlgc#0.1.0: Portabilité des Données LGC(fr)

## Pages

* [Accueil](index.md)
* [](ActorDefinition-PDLGC-Systeme-Destinataire.change.history.md)
* [](ActorDefinition-PDLGC-Demandeur.change.history.md)
* [LGC émetteur - XML Representation](ActorDefinition-PDLGC-Systeme-Emetteur.xml.md)
* [LGC émetteur - TTL Representation](ActorDefinition-PDLGC-Systeme-Emetteur.ttl.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire.md)
* [](ActorDefinition-PDLGC-Systeme-Emetteur.change.history.md)
* [Autres Ressources](autres_ressources.md)
* [LGC Destinataire](ActorDefinition-PDLGC-Systeme-Destinataire-testing.md)
* [PDLGC Demandeur - JSON Representation](ActorDefinition-PDLGC-Demandeur.json.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire-testing.md)
* [PDLGC Destinataire - TTL Representation](ActorDefinition-PDLGC-Destinataire.ttl.md)
* [LGC Destinataire - TTL Representation](ActorDefinition-PDLGC-Systeme-Destinataire.ttl.md)
* [LGC émetteur](ActorDefinition-PDLGC-Systeme-Emetteur.ai.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur.md)
* [Historique des versions](change-log.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur-testing.md)
* [PDLGC Demandeur - TTL Representation](ActorDefinition-PDLGC-Demandeur.ttl.md)
* [Structure de l'archive de portabilité](specs-main-structure-archive.md)
* [PDLGC Demandeur - XML Representation](ActorDefinition-PDLGC-Demandeur.xml.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur.ai.md)
* [Flux Export d'Archive de Portabilité](specs-main-flux-export-archive-portabilite.md)
* [LGC Destinataire - JSON Representation](ActorDefinition-PDLGC-Systeme-Destinataire.json.md)
* [](ActorDefinition-PDLGC-Destinataire.change.history.md)
* [Annexes](annexes.md)
* [Spécifications](specifications.md)
* [PDLGC Destinataire - JSON Representation](ActorDefinition-PDLGC-Destinataire.json.md)
* [Résumé des artefacts](artifacts.md)
* [Références](annexe-references.md)
* [Téléchargements et usages](annexe-downloads.md)
* [LGC Destinataire - XML Representation](ActorDefinition-PDLGC-Systeme-Destinataire.xml.md)
* [LGC Destinataire](ActorDefinition-PDLGC-Systeme-Destinataire.md)
* [LGC émetteur](ActorDefinition-PDLGC-Systeme-Emetteur.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire.ai.md)
* [Informations sur la traduction](translationinfo.md)
* [LGC émetteur](ActorDefinition-PDLGC-Systeme-Emetteur-testing.md)
* [LGC émetteur - JSON Representation](ActorDefinition-PDLGC-Systeme-Emetteur.json.md)
* [Sécurité](annexe-securite.md)
* [PDLGC Destinataire - XML Representation](ActorDefinition-PDLGC-Destinataire.xml.md)
* [LGC Destinataire](ActorDefinition-PDLGC-Systeme-Destinataire.ai.md)

## Resources

### CodeSystems

* [Type d'archive](CodeSystem-cs-pdlgc-archive-type.md)
* [Statut de l'export](CodeSystem-cs-pdlgc-export-status.md)
* [Type d'export de données LGC](CodeSystem-cs-pdlgc-export-type.md)
* [Type de moyen de communication](CodeSystem-cs-pdlgc-telecom-type.md)
* [Type d'association XDS](CodeSystem-cs-xdm-association-type.md)

### ValueSets

* [Type d'association XDS (VS)](ValueSet-vs-association-type.md)
* [PDLGC Type d'archive](ValueSet-vs-pdlgc-archive-type.md)
* [PDLGC Statut de l'export](ValueSet-vs-pdlgc-export-status.md)
* [PDLGC Type d'Export](ValueSet-vs-pdlgc-export-type.md)
* [PDLGC Type de moyen de communication](ValueSet-vs-pdlgc-telecom-type.md)

### Logicals

* [PDLGC Archive Patient](StructureDefinition-pdlgcArchivePatient.md)
* [PDLGC Archive Portabilite](StructureDefinition-pdlgcArchivePortabilite.md)
* [PDLGC Archive Transverse](StructureDefinition-pdlgcArchiveTransverse.md)
* [PDLGC Author](StructureDefinition-pdlgcAuthor.md)
* [PDLGC Contact Portabilite](StructureDefinition-pdlgcContactPortabilite.md)
* [PDLGC Documentation](StructureDefinition-pdlgcDocumentation.md)
* [PDLGC Index](StructureDefinition-pdlgcIndex.md)
* [PDLGC Manifest](StructureDefinition-pdlgcManifest.md)
* [PDLGC Metadata](StructureDefinition-pdlgcMetadata.md)
* [PDLGC Readme](StructureDefinition-pdlgcReadme.md)
* [PDLGC SoftwareVendor](StructureDefinition-pdlgcSoftwareVendor.md)
* [XDM ActorPatient](StructureDefinition-xdmActorPatient.md)
* [XDM ActorPS](StructureDefinition-xdmActorPs.md)
* [XDM ActorSystem](StructureDefinition-xdmActorSystem.md)
* [XDM ActorXDS Core](StructureDefinition-xdmActorXdsCore.md)
* [XDM Archive XDM](StructureDefinition-xdmArchive.md)
* [XDM Association](StructureDefinition-xdmAssociation.md)
* [XDM Author](StructureDefinition-xdmAuthor.md)
* [XDM AuthorDocumentEntry](StructureDefinition-xdmAuthorDocumentEntry.md)
* [XDM AuthorInstitution](StructureDefinition-xdmAuthorInstitution.md)
* [XDM AuthorSubmissionSet](StructureDefinition-xdmAuthorSubmissionSet.md)
* [Code XDM](StructureDefinition-xdmCode.md)
* [XDM DocumentEntry](StructureDefinition-xdmDocumentEntry.md)
* [XDM PatientId](StructureDefinition-xdmPatientId.md)
* [XDM SourcePatientId](StructureDefinition-xdmSourcePatientId.md)
* [XDM SourcePatientInfo](StructureDefinition-xdmSourcePatientInfo.md)
* [XDM SubmissionSet](StructureDefinition-xdmSubmissionSet.md)
* [XDM referenceIdList](StructureDefinition-xdmreferenceId.md)

### Primitive-type Profiles

* [Identifiant Patient](StructureDefinition-patId.md)
* [PSIdNat](StructureDefinition-psIdNat.md)
* [StructIdNat](StructureDefinition-structIdNat.md)
* [SystIdNat](StructureDefinition-systIdNat.md)

### Basics

* [PDLGC-Demandeur](Basic-PDLGC-Demandeur.md)
* [PDLGC-Destinataire](Basic-PDLGC-Destinataire.md)
* [PDLGC-Systeme-Destinataire](Basic-PDLGC-Systeme-Destinataire.md)
* [PDLGC-Systeme-Emetteur](Basic-PDLGC-Systeme-Emetteur.md)

### ImplementationGuides

* [Portabilité des Données LGC](ImplementationGuide-ans.fhir.fr.pdlgc.md)
