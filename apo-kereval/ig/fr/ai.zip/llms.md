# ans.fhir.fr.pdlgc#0.1.0: Portabilité des Données LGC(fr)

## Pages

* [Accueil](index.md)
* [Annexes](annexes.md)
* [Informations sur la traduction](translationinfo.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire-testing.md)
* [Sécurité](annexe-securite.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur-testing.md)
* [PDLGC Fournisseur Destinataire - TTL Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.ttl.md)
* [Autres Ressources](autres_ressources.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire.md)
* [Vol1 - Etude Fonctionnelle](sf-etude-fonctionnelle.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant-testing.md)
* [](ActorDefinition-PDLGC-Fournisseur-Destinataire.change.history.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire.ai.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur.ai.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant.md)
* [Résumé des artefacts](artifacts.md)
* [PDLGC Demandeur - XML Representation](ActorDefinition-PDLGC-Demandeur.xml.md)
* [PDLGC Destinataire - JSON Representation](ActorDefinition-PDLGC-Destinataire.json.md)
* [PDLGC Demandeur - JSON Representation](ActorDefinition-PDLGC-Demandeur.json.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant.ai.md)
* [PDLGC Fournisseur Sortant - TTL Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.ttl.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur.md)
* [PDLGC Fournisseur Sortant - XML Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.xml.md)
* [Historique des versions](change-log.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire.ai.md)
* [](ActorDefinition-PDLGC-Destinataire.change.history.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire-testing.md)
* [](ActorDefinition-PDLGC-Fournisseur-Sortant.change.history.md)
* [PDLGC Destinataire - TTL Representation](ActorDefinition-PDLGC-Destinataire.ttl.md)
* [](ActorDefinition-PDLGC-Demandeur.change.history.md)
* [Téléchargements et usages](annexe-downloads.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire.md)
* [PDLGC Fournisseur Sortant - JSON Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.json.md)
* [PDLGC Fournisseur Destinataire - JSON Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.json.md)
* [PDLGC Fournisseur Destinataire - XML Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.xml.md)
* [PDLGC Demandeur - TTL Representation](ActorDefinition-PDLGC-Demandeur.ttl.md)
* [PDLGC Destinataire - XML Representation](ActorDefinition-PDLGC-Destinataire.xml.md)

## Resources

### CodeSystems

* [Type d'association XDS](CodeSystem-cs-association-type.md)

### ValueSets

* [Type d'association XDS (VS)](ValueSet-vs-association-type.md)

### Logicals

* [ActorPS (LM)](StructureDefinition-ActorPS.md)
* [ActorPatient (LM)](StructureDefinition-ActorPatient.md)
* [ActorSNR (LM)](StructureDefinition-ActorSNR.md)
* [ActorSystem (LM)](StructureDefinition-ActorSystem.md)
* [ActorXDS (LM)](StructureDefinition-ActorXDS.md)
* [Author (LM)](StructureDefinition-Author.md)
* [AuthorDocumentEntry (LM)](StructureDefinition-AuthorDocumentEntry.md)
* [AuthorInstitution (LM)](StructureDefinition-AuthorInstitution.md)
* [AuthorSubmissionSet (LM)](StructureDefinition-AuthorSubmissionSet.md)
* [Document Entry (LM)](StructureDefinition-DocumentEntry.md)
* [EventCode (LM)](StructureDefinition-EventCode.md)
* [Identifiant](StructureDefinition-Identifiant.md)
* [MatriculeINS](StructureDefinition-MatriculeINS.md)
* [PSIdNat](StructureDefinition-PSIdNat.md)
* [PatientId (LM)](StructureDefinition-PatientId.md)
* [SNR](StructureDefinition-SNR.md)
* [SourcePatientId (LM)](StructureDefinition-SourcePatientId.md)
* [SourcePatientInfo (LM)](StructureDefinition-SourcePatientInfo.md)
* [StructIdNat](StructureDefinition-StructIdNat.md)
* [SubmissionSet (LM)](StructureDefinition-SubmissionSet.md)
* [Archive XDM (LM)](StructureDefinition-archive-xdm.md)
* [Association XDM (LM)](StructureDefinition-association-xdm.md)

### Primitive-type Profiles

* [IdentifiantSysteme](StructureDefinition-IdentifiantSysteme.md)

### Basics

* [PDLGC-Demandeur](Basic-PDLGC-Demandeur.md)
* [PDLGC-Destinataire](Basic-PDLGC-Destinataire.md)
* [PDLGC-Fournisseur-Destinataire](Basic-PDLGC-Fournisseur-Destinataire.md)
* [PDLGC-Fournisseur-Sortant](Basic-PDLGC-Fournisseur-Sortant.md)

### ImplementationGuides

* [Portabilité des Données LGC](ImplementationGuide-ans.fhir.fr.pdlgc.md)
