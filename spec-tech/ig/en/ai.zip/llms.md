# ans.fhir.fr.pdlgc#0.1.0: Portabilité des Données LGC(en)

## Pages

* [Accueil](index.md)
* [PDLGC Demandeur - JSON Representation](ActorDefinition-PDLGC-Demandeur.json.md)
* [PDLGC Destinataire - XML Representation](ActorDefinition-PDLGC-Destinataire.xml.md)
* [PDLGC Demandeur - TTL Representation](ActorDefinition-PDLGC-Demandeur.ttl.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire-testing.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant.ai.md)
* [PDLGC Fournisseur Destinataire - XML Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.xml.md)
* [PDLGC Destinataire - TTL Representation](ActorDefinition-PDLGC-Destinataire.ttl.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur.ai.md)
* [](ActorDefinition-PDLGC-Fournisseur-Destinataire.change.history.md)
* [Flux Export d'Archive de Portabilité](specs-main-flux-export-archive-portabilite.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur-testing.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant.md)
* [PDLGC Fournisseur Destinataire - TTL Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.ttl.md)
* [Structure de l'archive de portabilité](struct-main-structure-archive.md)
* [Informations sur la traduction](translationinfo.md)
* [Références](annexe-references.md)
* [Autres Ressources](autres_ressources.md)
* [PDLGC Fournisseur Destinataire - JSON Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.json.md)
* [Artifacts Summary](artifacts.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire.ai.md)
* [Téléchargements et usages](annexe-downloads.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire-testing.md)
* [Spécifications](specifications.md)
* [](ActorDefinition-PDLGC-Destinataire.change.history.md)
* [PDLGC Fournisseur Sortant - TTL Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.ttl.md)
* [PDLGC Destinataire - JSON Representation](ActorDefinition-PDLGC-Destinataire.json.md)
* [](ActorDefinition-PDLGC-Fournisseur-Sortant.change.history.md)
* [PDLGC Fournisseur Sortant - JSON Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.json.md)
* [Historique des versions](change-log.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire.ai.md)
* [](ActorDefinition-PDLGC-Demandeur.change.history.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant-testing.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire.md)
* [PDLGC Fournisseur Sortant - XML Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.xml.md)
* [PDLGC Destinataire](ActorDefinition-PDLGC-Destinataire.md)
* [Sécurité](annexe-securite.md)
* [PDLGC Demandeur](ActorDefinition-PDLGC-Demandeur.md)
* [Annexes](annexes.md)
* [PDLGC Demandeur - XML Representation](ActorDefinition-PDLGC-Demandeur.xml.md)

## Resources

### CodeSystems

* [Statut de l'export](CodeSystem-pdlgc-export-status-cs.md)
* [Type de répertoire](CodeSystem-pdlgc-repo-type-cs.md)
* [Type d'export de données LGC](CodeSystem-pdlgc-type-export-cs.md)

### ValueSets

* [PDLGC Statut de l'export](ValueSet-pdlgc-export-status-vs.md)
* [PDLGC Type d'Export](ValueSet-pdlgc-export-type-vs.md)
* [PDLGC Type de répertoire](ValueSet-pdlgc-repo-type-vs.md)

### Logicals

* [PDLGC Archive Patient](StructureDefinition-pdlgc-archive-patient.md)
* [PDLGC Archive Portabilite](StructureDefinition-pdlgc-archive-portabilite.md)
* [PDLGC Archive Transverse](StructureDefinition-pdlgc-archive-transverse.md)
* [PDLGC Contact Portabilite](StructureDefinition-pdlgc-contact-portabilite.md)
* [PDLGC Documentation](StructureDefinition-pdlgc-documentation.md)
* [PDLGC Fournisseur Sortant](StructureDefinition-pdlgc-fournisseur-sortant.md)
* [PDLGC Index](StructureDefinition-pdlgc-index.md)
* [PDLGC Manifest Archives](StructureDefinition-pdlgc-manifest-archives.md)
* [PDLGC Manifest](StructureDefinition-pdlgc-manifest.md)
* [PDLGC Metadata](StructureDefinition-pdlgc-metadata.md)
* [PDLGC Readme](StructureDefinition-pdlgc-readme.md)
* [PDLGC Signature](StructureDefinition-pdlgc-signature.md)
* [PDLGC System](StructureDefinition-pdlgc-system.md)

### Basics

* [PDLGC-Demandeur](Basic-PDLGC-Demandeur.md)
* [PDLGC-Destinataire](Basic-PDLGC-Destinataire.md)
* [PDLGC-Fournisseur-Destinataire](Basic-PDLGC-Fournisseur-Destinataire.md)
* [PDLGC-Fournisseur-Sortant](Basic-PDLGC-Fournisseur-Sortant.md)

### ImplementationGuides

* [Portabilité des Données LGC](ImplementationGuide-ans.fhir.fr.pdlgc.md)
