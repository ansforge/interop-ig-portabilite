# Annexes - Portabilité des Données LGC v1.0.0

## Annexes

 
There is no translation page available for the current page, so it has been rendered in the default language 

* [Téléchargements et usage](./downloads.md)
* [Spécifications FHIR](http://hl7.org/fhir/R4/index.html)
* [Site de l'ANS](https://esante.gouv.fr/)

