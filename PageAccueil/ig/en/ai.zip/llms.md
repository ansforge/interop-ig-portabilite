# ans.fhir.fr.pdlgc#1.0.0: Portabilité des Données LGC(en)

## Pages

* [Accueil](index.md)
* [PDLGC Professionnel de Santé Destinataire - TTL Representation](ActorDefinition-PDLGC-PS-Destinataire.ttl.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant.ai.md)
* [PDLGC Fournisseur Destinataire - XML Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.xml.md)
* [PDLGC Professionnel de Santé Initiateur](ActorDefinition-PDLGC-PS-Initiateur.md)
* [](ActorDefinition-PDLGC-PS-Initiateur.change.history.md)
* [PDLGC Professionnel de Santé Initiateur - JSON Representation](ActorDefinition-PDLGC-PS-Initiateur.json.md)
* [](ActorDefinition-PDLGC-Fournisseur-Destinataire.change.history.md)
* [PDLGC Professionnel de Santé Destinataire - JSON Representation](ActorDefinition-PDLGC-PS-Destinataire.json.md)
* [PDLGC Patient](ActorDefinition-PDLGC-Patient.ai.md)
* [PDLGC Patient](ActorDefinition-PDLGC-Patient.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant.md)
* [PDLGC Fournisseur Destinataire - TTL Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.ttl.md)
* [PDLGC Professionnel de Santé Destinataire](ActorDefinition-PDLGC-PS-Destinataire-testing.md)
* [Informations sur la traduction](translationinfo.md)
* [PDLGC Professionnel de Santé Destinataire](ActorDefinition-PDLGC-PS-Destinataire.md)
* [Autres Ressources](autres_ressources.md)
* [](ActorDefinition-PDLGC-PS-Destinataire.change.history.md)
* [PDLGC Professionnel de Santé Initiateur - XML Representation](ActorDefinition-PDLGC-PS-Initiateur.xml.md)
* [PDLGC Fournisseur Destinataire - JSON Representation](ActorDefinition-PDLGC-Fournisseur-Destinataire.json.md)
* [Artifacts Summary](artifacts.md)
* [Téléchargements et usages](annexe-downloads.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire-testing.md)
* [Spécifications](specifications.md)
* [PDLGC Professionnel de Santé Destinataire](ActorDefinition-PDLGC-PS-Destinataire.ai.md)
* [PDLGC Professionnel de Santé Destinataire - XML Representation](ActorDefinition-PDLGC-PS-Destinataire.xml.md)
* [PDLGC Fournisseur Sortant - TTL Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.ttl.md)
* [](ActorDefinition-PDLGC-Fournisseur-Sortant.change.history.md)
* [PDLGC Fournisseur Sortant - JSON Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.json.md)
* [PDLGC Professionnel de Santé Initiateur](ActorDefinition-PDLGC-PS-Initiateur-testing.md)
* [PDLGC Patient - XML Representation](ActorDefinition-PDLGC-Patient.xml.md)
* [PDLGC Patient](ActorDefinition-PDLGC-Patient-testing.md)
* [Historique des versions](change-log.md)
* [PDLGC Professionnel de Santé Initiateur](ActorDefinition-PDLGC-PS-Initiateur.ai.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire.ai.md)
* [PDLGC Fournisseur Sortant](ActorDefinition-PDLGC-Fournisseur-Sortant-testing.md)
* [PDLGC Fournisseur Destinataire](ActorDefinition-PDLGC-Fournisseur-Destinataire.md)
* [PDLGC Professionnel de Santé Initiateur - TTL Representation](ActorDefinition-PDLGC-PS-Initiateur.ttl.md)
* [PDLGC Fournisseur Sortant - XML Representation](ActorDefinition-PDLGC-Fournisseur-Sortant.xml.md)
* [Sécurité](annexe-securite.md)
* [](ActorDefinition-PDLGC-Patient.change.history.md)
* [Annexes](annexes.md)
* [PDLGC Patient - TTL Representation](ActorDefinition-PDLGC-Patient.ttl.md)
* [PDLGC Patient - JSON Representation](ActorDefinition-PDLGC-Patient.json.md)

## Resources

### CodeSystems

* [Compétences CodeSystem](CodeSystem-competence-code-system.md)
* [Type de carte](CodeSystem-type-carte-code-system.md)

### ValueSets

* [EyeColor Value Set](ValueSet-EyeColorVS.md)
* [Melting Pot Value Set](ValueSet-MeltingPotVS.md)
* [ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md)
* [Type Carte Value Set](ValueSet-TypeCarteVS.md)

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### Extensions

* [EyeColor](StructureDefinition-EyeColor.md)

### Basics

* [PDLGC-Fournisseur-Destinataire](Basic-PDLGC-Fournisseur-Destinataire.md)
* [PDLGC-Fournisseur-Sortant](Basic-PDLGC-Fournisseur-Sortant.md)
* [PDLGC-PS-Destinataire](Basic-PDLGC-PS-Destinataire.md)
* [PDLGC-PS-Initiateur](Basic-PDLGC-PS-Initiateur.md)
* [PDLGC-Patient](Basic-PDLGC-Patient.md)

### ImplementationGuides

* [Portabilité des Données LGC](ImplementationGuide-ans.fhir.fr.pdlgc.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
