# Historique des versions - Portabilité des Données LGC v1.0.0

## Historique des versions

### version xxx

**Release xxx de l'Implementation Guide FHIR xxx.**

URL : [https://interop.esante.gouv.fr/ig/fhir/xxx](https://interop.esante.gouv.fr/ig/fhir/xxx)

[Modifications apportées dans cette release](https://github.com/ansforge/xxx/milestone/10?closed=1) :

* [narratif] modification xxx [numéro d'issue](https://github.com/ansforge/xxx/issues/numéro d'issue)

